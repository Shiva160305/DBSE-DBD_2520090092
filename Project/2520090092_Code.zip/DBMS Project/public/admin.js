// ============================================================
// ADMIN.JS
// ============================================================


// ============================================================
// CAMERA
// ============================================================

let cameraStream = null;

let capturedFace = null;


// ============================================================
// START CAMERA
// ============================================================

async function startCamera() {

    const video =
        document.getElementById("video");

    const status =
        document.getElementById("cameraStatus");


    try {

        // Check browser support

        if (!navigator.mediaDevices ||
            !navigator.mediaDevices.getUserMedia
        ) {

            status.innerText =
                "Camera is not supported by this browser.";

            return;

        }


        status.innerText =
            "Requesting camera permission...";


        // Ask for camera

        cameraStream =
            await navigator.mediaDevices.getUserMedia({

                video: {

                    width: {
                        ideal: 640
                    },

                    height: {
                        ideal: 480
                    },

                    facingMode: "user"

                },

                audio: false

            });


        // Put camera stream into video

        video.srcObject =
            cameraStream;


        // Make sure video plays

        await video.play();


        status.innerText =
            "✅ Camera is working. Face the camera.";

        status.style.color =
            "green";


    } catch (error) {

        console.error(
            "Camera error:",
            error
        );


        status.style.color =
            "red";


        if (
            error.name ===
            "NotAllowedError"
        ) {

            status.innerText =
                "❌ Camera permission was denied. Allow camera access in the browser.";

        } else if (
            error.name ===
            "NotFoundError"
        ) {

            status.innerText =
                "❌ No camera was found on this device.";

        } else if (
            error.name ===
            "NotReadableError"
        ) {

            status.innerText =
                "❌ Camera is already being used by another application.";

        } else {

            status.innerText =
                "❌ Could not start camera: " +
                error.message;

        }

    }

}


// ============================================================
// CAPTURE FACE IMAGE
// ============================================================

function captureFace() {

    const video =
        document.getElementById("video");

    const status =
        document.getElementById("cameraStatus");


    // Check camera

    if (!video.srcObject) {

        status.innerText =
            "❌ Start the camera first.";

        status.style.color =
            "red";

        return;

    }


    // Create canvas

    const canvas =
        document.createElement("canvas");


    canvas.width =
        video.videoWidth;

    canvas.height =
        video.videoHeight;


    const context =
        canvas.getContext("2d");


    context.drawImage(

        video,

        0,

        0,

        canvas.width,

        canvas.height

    );


    // Convert image to data URL

    capturedFace =
        canvas.toDataURL(
            "image/jpeg",
            0.8
        );


    status.innerText =
        "✅ Face image captured successfully.";

    status.style.color =
        "green";


    console.log(
        "Face captured."
    );

}


// ============================================================
// REGISTER STUDENT
// ============================================================

async function registerStudent() {

    const name =
        document
        .getElementById("studentName")
        .value
        .trim();


    const section =
        document
        .getElementById("studentSection")
        .value
        .trim();


    const rollNumber =
        document
        .getElementById("rollNumber")
        .value
        .trim();


    const status =
        document
        .getElementById("registerStatus");


    // Validate name

    if (!name) {

        status.innerText =
            "Please enter the student's name.";

        return;

    }


    // Validate section

    if (!section) {

        status.innerText =
            "Please enter the section.";

        return;

    }


    // Validate roll number

    if (!rollNumber) {

        status.innerText =
            "Please enter the roll number.";

        return;

    }


    // Validate face

    if (!capturedFace) {

        status.innerText =
            "Please start the camera and capture the student's face.";

        return;

    }


    status.innerText =
        "Registering student...";


    try {

        /*
         * For now we send the captured image.
         * Your server can store this data.
         */

        const response =
            await fetch(
                "/api/register", {

                    method: "POST",

                    headers: {

                        "Content-Type": "application/json"

                    },

                    body: JSON.stringify({

                        name: name,

                        section: section,

                        rollNumber: rollNumber,

                        faceDescriptor: capturedFace

                    })

                }
            );


        if (
            response.status === 401
        ) {

            window.location.href =
                "/login.html";

            return;

        }


        const result =
            await response.json();


        if (
            result.success
        ) {

            status.innerText =
                "✅ Student registered successfully!";

            status.style.color =
                "green";


            // Clear form

            document
                .getElementById(
                    "studentName"
                )
                .value = "";


            document
                .getElementById(
                    "studentSection"
                )
                .value = "";


            document
                .getElementById(
                    "rollNumber"
                )
                .value = "";


            capturedFace =
                null;


            loadDashboard();

        } else {

            status.innerText =
                "❌ " +
                result.message;

            status.style.color =
                "red";

        }

    } catch (error) {

        console.error(
            "Registration error:",
            error
        );


        status.innerText =
            "❌ Could not connect to the server.";

        status.style.color =
            "red";

    }

}


// ============================================================
// LOAD DASHBOARD
// ============================================================

async function loadDashboard() {

    try {

        const response =
            await fetch(
                "/api/dashboard"
            );


        if (
            response.status === 401
        ) {

            window.location.href =
                "/login.html";

            return;

        }


        const data =
            await response.json();


        if (!data.success) {

            return;

        }


        document
            .getElementById(
                "totalStudents"
            )
            .innerText =
            data.totalStudents;


        document
            .getElementById(
                "presentToday"
            )
            .innerText =
            data.presentToday;


        document
            .getElementById(
                "absentToday"
            )
            .innerText =
            data.absentToday;


        document
            .getElementById(
                "dashboardDate"
            )
            .innerText =
            "Date: " + data.date;


        displayPresentStudents(
            data.presentStudents
        );

    } catch (error) {

        console.error(
            "Dashboard error:",
            error
        );

    }

}


// ============================================================
// DISPLAY PRESENT STUDENTS
// ============================================================

function displayPresentStudents(
    students
) {

    const container =
        document.getElementById(
            "presentStudents"
        );


    if (!students ||
        students.length === 0
    ) {

        container.innerHTML = `

            <div class="no-students">

                <p>
                    No students have marked
                    attendance today.
                </p>

            </div>

        `;

        return;

    }


    let html = `

        <table class="attendance-table">

            <thead>

                <tr>

                    <th>#</th>

                    <th>
                        Student Name
                    </th>

                    <th>
                        Section
                    </th>

                    <th>
                        Roll Number
                    </th>

                    <th>
                        Time
                    </th>

                </tr>

            </thead>

            <tbody>

    `;


    students.forEach(
        (student, index) => {

            html += `

                <tr>

                    <td>
                        ${index + 1}
                    </td>

                    <td class="student-name">
                        ${escapeHTML(
                            student.name
                        )}
                    </td>

                    <td>
                        ${escapeHTML(
                            student.section
                        )}
                    </td>

                    <td>
                        ${escapeHTML(
                            student.roll_number
                        )}
                    </td>

                    <td>
                        ${escapeHTML(
                            student.time
                        )}
                    </td>

                </tr>

            `;

        }
    );


    html += `

            </tbody>

        </table>

    `;


    container.innerHTML =
        html;

}


// ============================================================
// ESCAPE HTML
// ============================================================

function escapeHTML(
    value
) {

    const div =
        document.createElement(
            "div"
        );

    div.textContent =
        value ?? "";

    return div.innerHTML;

}


// ============================================================
// LOGOUT
// ============================================================

async function logout() {

    try {

        const response =
            await fetch(
                "/api/admin/logout", {
                    method: "POST"
                }
            );


        const result =
            await response.json();


        if (
            result.success
        ) {

            window.location.href =
                "/login.html";

        }

    } catch (error) {

        console.error(
            "Logout error:",
            error
        );

    }

}


// ============================================================
// PAGE LOAD
// ============================================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        loadDashboard();

    }
);