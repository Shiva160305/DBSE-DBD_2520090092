// ==========================================
// ADMIN LOGIN
// ==========================================

async function login() {

    // Get username
    const username =
        document
        .getElementById("username")
        .value
        .trim();


    // Get password
    const password =
        document
        .getElementById("password")
        .value;


    // Status message
    const status =
        document
        .getElementById("loginStatus");


    // Check empty fields
    if (!username || !password) {

        status.innerText =
            "Please enter username and password.";

        status.style.color = "red";

        return;

    }


    status.innerText =
        "Logging in...";

    status.style.color = "black";


    try {

        // Send login information to server
        const response =
            await fetch(
                "/api/admin/login", {

                    method: "POST",

                    headers: {

                        "Content-Type": "application/json"

                    },

                    body: JSON.stringify({

                        username: username,

                        password: password

                    })

                }
            );


        // Convert response to JSON
        const result =
            await response.json();


        // Login successful
        if (result.success) {

            status.innerText =
                "Login successful!";

            status.style.color =
                "green";


            // Open admin dashboard
            setTimeout(
                function() {

                    window.location.href =
                        "/admin.html";

                },
                500
            );

        }

        // Login failed
        else {

            status.innerText =
                result.message ||
                "Invalid username or password.";

            status.style.color =
                "red";

        }

    } catch (error) {

        console.error(
            "Login error:",
            error
        );


        status.innerText =
            "Could not connect to the server.";

        status.style.color =
            "red";

    }

}


// ==========================================
// ALLOW ENTER KEY TO LOGIN
// ==========================================

document.addEventListener(
    "keydown",
    function(event) {

        if (event.key === "Enter") {

            login();

        }

    }
);