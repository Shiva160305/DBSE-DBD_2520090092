// ==========================================
// SETTINGS
// ==========================================

const MODEL_URL =
    "https://justadudewhohacks.github.io/face-api.js/models";

const FACE_MATCH_THRESHOLD = 0.5;


// ==========================================
// VARIABLES
// ==========================================

const video =
    document.getElementById("video");

const statusText =
    document.getElementById("status");

let students = [];

let cameraStarted = false;


// ==========================================
// STATUS MESSAGE
// ==========================================

function setStatus(message) {

    statusText.innerText = message;

}


// ==========================================
// LOAD FACE RECOGNITION MODELS
// ==========================================

async function loadModels() {

    try {

        setStatus(
            "Loading face recognition models..."
        );


        await faceapi.nets.tinyFaceDetector
            .loadFromUri(MODEL_URL);


        await faceapi.nets.faceLandmark68Net
            .loadFromUri(MODEL_URL);


        await faceapi.nets.faceRecognitionNet
            .loadFromUri(MODEL_URL);


        setStatus(
            "Face recognition loaded. Start the camera."
        );


        console.log(
            "Face recognition models loaded."
        );

    } catch (error) {

        console.error(error);

        setStatus(
            "Could not load face recognition models."
        );

    }

}


// ==========================================
// START CAMERA
// ==========================================

async function startCamera() {

    try {

        if (cameraStarted) {

            setStatus(
                "Camera is already running."
            );

            return;

        }


        const stream =
            await navigator.mediaDevices
            .getUserMedia({
                video: {
                    width: 640,
                    height: 480
                },
                audio: false
            });


        video.srcObject = stream;

        cameraStarted = true;


        setStatus(
            "Camera started. Look directly at the camera."
        );

    } catch (error) {

        console.error(error);

        setStatus(
            "Camera permission was denied or camera is unavailable."
        );

    }

}


// ==========================================
// GET FACE DESCRIPTOR
// ==========================================

async function getFaceDescriptor() {

    if (!cameraStarted) {

        alert(
            "Please start the camera first."
        );

        return null;

    }


    const detection =
        await faceapi
        .detectSingleFace(
            video,
            new faceapi.TinyFaceDetectorOptions({
                inputSize: 416,
                scoreThreshold: 0.5
            })
        )
        .withFaceLandmarks()
        .withFaceDescriptor();


    if (!detection) {

        return null;

    }


    return Array.from(
        detection.descriptor
    );

}


// ==========================================
// REGISTER STUDENT
// ==========================================

async function registerStudent() {

    const name =
        document
        .getElementById("name")
        .value
        .trim();


    const section =
        document
        .getElementById("section")
        .value
        .trim();


    const rollNumber =
        document
        .getElementById("rollNumber")
        .value
        .trim();


    if (!name || !section || !rollNumber) {

        alert(
            "Please enter Name, Section and Roll Number."
        );

        return;

    }


    if (!cameraStarted) {

        alert(
            "Please start the camera first."
        );

        return;

    }


    setStatus(
        "Detecting your face..."
    );


    const faceDescriptor =
        await getFaceDescriptor();


    if (!faceDescriptor) {

        setStatus(
            "No face detected. Please look directly at the camera."
        );

        return;

    }


    setStatus(
        "Saving student..."
    );


    try {

        const response =
            await fetch(
                "/api/register", {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({

                        name: name,

                        section: section,

                        rollNumber: rollNumber,

                        faceDescriptor: faceDescriptor

                    })

                }
            );


        const result =
            await response.json();


        if (result.success) {

            alert(
                "Student registered successfully!"
            );


            document
                .getElementById("name")
                .value = "";


            document
                .getElementById("section")
                .value = "";


            document
                .getElementById("rollNumber")
                .value = "";


            setStatus(
                "Student registered. You can now mark attendance."
            );

        } else {

            alert(result.message);

            setStatus(
                result.message
            );

        }

    } catch (error) {

        console.error(error);

        alert(
            "Could not connect to the server."
        );

        setStatus(
            "Server connection error."
        );

    }

}


// ==========================================
// LOAD STUDENTS
// ==========================================

async function loadStudents() {

    try {

        const response =
            await fetch(
                "/api/students"
            );


        students =
            await response.json();


        console.log(
            "Students loaded:",
            students.length
        );

    } catch (error) {

        console.error(error);

    }

}


// ==========================================
// CALCULATE FACE DISTANCE
// ==========================================

function calculateDistance(
    descriptor1,
    descriptor2
) {

    let sum = 0;


    for (
        let i = 0; i < descriptor1.length; i++
    ) {

        const difference =
            descriptor1[i] -
            descriptor2[i];


        sum +=
            difference * difference;

    }


    return Math.sqrt(sum);

}


// ==========================================
// FIND MATCHING STUDENT
// ==========================================

function findMatchingStudent(
    currentDescriptor
) {

    let bestStudent = null;

    let smallestDistance =
        Infinity;


    for (
        const student of students
    ) {

        const registeredDescriptor =
            new Float32Array(
                student.face_descriptor
            );


        const distance =
            calculateDistance(
                currentDescriptor,
                registeredDescriptor
            );


        console.log(
            student.name,
            distance
        );


        if (
            distance <
            smallestDistance
        ) {

            smallestDistance =
                distance;

            bestStudent =
                student;

        }

    }


    if (
        bestStudent &&
        smallestDistance <=
        FACE_MATCH_THRESHOLD
    ) {

        return {
            student: bestStudent,
            distance: smallestDistance
        };

    }


    return null;

}


// ==========================================
// MARK ATTENDANCE
// ==========================================

async function markAttendance() {

    if (!cameraStarted) {

        alert(
            "Please start the camera first."
        );

        return;

    }


    await loadStudents();


    if (students.length === 0) {

        alert(
            "No students are registered yet."
        );

        return;

    }


    setStatus(
        "Looking for your face..."
    );


    const currentDescriptor =
        await getFaceDescriptor();


    if (!currentDescriptor) {

        setStatus(
            "No face detected. Please look at the camera."
        );

        return;

    }


    setStatus(
        "Comparing face..."
    );


    const match =
        findMatchingStudent(
            currentDescriptor
        );


    if (!match) {

        setStatus(
            "Face not recognized."
        );

        alert(
            "Face not recognized. Please register the student first."
        );

        return;

    }


    const student =
        match.student;


    setStatus(
        `Recognized: ${student.name}`
    );


    try {

        const response =
            await fetch(
                "/api/attendance", {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({

                        studentId: student.id

                    })

                }
            );


        const result =
            await response.json();


        if (result.success) {

            alert(
                `${student.name}\n\nAttendance marked successfully!\n\nDate: ${result.date}\nTime: ${result.time}`
            );

        } else {

            alert(
                `${student.name}\n\n${result.message}`
            );

        }


        await loadAttendance();

    } catch (error) {

        console.error(error);

        alert(
            "Could not connect to the server."
        );

    }

}


// ==========================================
// LOAD ATTENDANCE
// ==========================================

async function loadAttendance() {

    try {

        const response =
            await fetch(
                "/api/attendance"
            );


        const records =
            await response.json();


        const table =
            document.getElementById(
                "attendanceTable"
            );


        table.innerHTML = "";


        if (records.length === 0) {

            table.innerHTML = `
                <tr>
                    <td colspan="5">
                        No attendance records yet.
                    </td>
                </tr>
            `;

            return;

        }


        records.forEach(
            record => {

                const row =
                    document.createElement(
                        "tr"
                    );


                row.innerHTML = `

                    <td>
                        ${record.name}
                    </td>

                    <td>
                        ${record.section}
                    </td>

                    <td>
                        ${record.roll_number}
                    </td>

                    <td>
                        ${record.date}
                    </td>

                    <td>
                        ${record.time}
                    </td>

                `;


                table.appendChild(row);

            }
        );

    } catch (error) {

        console.error(error);

    }

}


// ==========================================
// INITIALIZE WEBSITE
// ==========================================

async function initialize() {

    setStatus(
        "Starting application..."
    );


    await loadModels();


    await loadStudents();


    await loadAttendance();

}


// Start application

initialize();