const MODEL_URL =
    "https://justadudewhohacks.github.io/face-api.js/models";


const FACE_MATCH_THRESHOLD = 0.5;


const video =
    document.getElementById("video");


const statusText =
    document.getElementById("status");


let students = [];

let cameraStarted = false;


// ======================================
// STATUS
// ======================================

function setStatus(message) {

    statusText.innerText = message;

}


// ======================================
// LOAD MODELS
// ======================================

async function loadModels() {

    try {

        setStatus(
            "Loading face recognition..."
        );


        await faceapi.nets.tinyFaceDetector
            .loadFromUri(MODEL_URL);


        await faceapi.nets.faceLandmark68Net
            .loadFromUri(MODEL_URL);


        await faceapi.nets.faceRecognitionNet
            .loadFromUri(MODEL_URL);


        setStatus(
            "Ready. Start the camera."
        );

    } catch (error) {

        console.error(error);

        setStatus(
            "Could not load face recognition."
        );

    }

}


// ======================================
// START CAMERA
// ======================================

async function startCamera() {

    try {

        if (cameraStarted) {

            setStatus(
                "Camera is already running."
            );

            return;

        }


        const stream =
            await navigator.mediaDevices
            .getUserMedia({

                video: {
                    width: 640,
                    height: 480
                },

                audio: false

            });


        video.srcObject = stream;

        cameraStarted = true;


        setStatus(
            "Camera started. Look directly at the camera."
        );

    } catch (error) {

        console.error(error);

        setStatus(
            "Could not access camera."
        );

    }

}


// ======================================
// LOAD STUDENTS
// ======================================

async function loadStudents() {

    try {

        const response =
            await fetch(
                "/api/students"
            );


        students =
            await response.json();


        console.log(
            "Students loaded:",
            students.length
        );

    } catch (error) {

        console.error(error);

    }

}


// ======================================
// FACE DISTANCE
// ======================================

function calculateDistance(
    descriptor1,
    descriptor2
) {

    let sum = 0;


    for (
        let i = 0; i < descriptor1.length; i++
    ) {

        const difference =
            descriptor1[i] -
            descriptor2[i];


        sum +=
            difference * difference;

    }


    return Math.sqrt(sum);

}


// ======================================
// FIND STUDENT
// ======================================

function findMatchingStudent(
    currentDescriptor
) {

    let bestStudent = null;

    let smallestDistance =
        Infinity;


    for (
        const student of students
    ) {

        const registeredDescriptor =
            new Float32Array(
                student.face_descriptor
            );


        const distance =
            calculateDistance(
                currentDescriptor,
                registeredDescriptor
            );


        if (
            distance <
            smallestDistance
        ) {

            smallestDistance =
                distance;

            bestStudent =
                student;

        }

    }


    if (
        bestStudent &&
        smallestDistance <=
        FACE_MATCH_THRESHOLD
    ) {

        return bestStudent;

    }


    return null;

}


// ======================================
// MARK ATTENDANCE
// ======================================

async function markAttendance() {

    if (!cameraStarted) {

        alert(
            "Please start the camera first."
        );

        return;

    }


    await loadStudents();


    if (students.length === 0) {

        alert(
            "No students are registered."
        );

        return;

    }


    setStatus(
        "Looking for your face..."
    );


    const detection =
        await faceapi
        .detectSingleFace(
            video,
            new faceapi.TinyFaceDetectorOptions()
        )
        .withFaceLandmarks()
        .withFaceDescriptor();


    if (!detection) {

        setStatus(
            "No face detected."
        );

        alert(
            "Please look directly at the camera."
        );

        return;

    }


    const currentDescriptor =
        detection.descriptor;


    setStatus(
        "Recognizing face..."
    );


    const student =
        findMatchingStudent(
            currentDescriptor
        );


    if (!student) {

        setStatus(
            "Face not recognized."
        );

        alert(
            "Face not recognized. Please contact the administrator."
        );

        return;

    }


    setStatus(
        `Recognized: ${student.name}`
    );


    try {

        const response =
            await fetch(
                "/api/attendance", {

                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({

                        studentId: student.id

                    })

                }
            );


        const result =
            await response.json();


        if (result.success) {

            alert(

                `Attendance Marked Successfully!\n\n` +

                `Name: ${student.name}\n` +

                `Section: ${student.section}\n` +

                `Roll Number: ${student.roll_number}\n` +

                `Date: ${result.date}\n` +

                `Time: ${result.time}`

            );

        } else {

            alert(
                result.message
            );

        }


        setStatus(
            result.message
        );

    } catch (error) {

        console.error(error);

        alert(
            "Server connection error."
        );

    }

}


// ======================================
// START
// ======================================

async function initialize() {

    await loadModels();

}


initialize();