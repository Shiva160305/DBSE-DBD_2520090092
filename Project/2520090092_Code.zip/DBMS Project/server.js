// ============================================================
// STUDENT FACE RECOGNITION ATTENDANCE SYSTEM
// SERVER.JS
// ============================================================

const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const cors = require("cors");
const session = require("express-session");
const path = require("path");

const app = express();
const PORT = 3000;


// ============================================================
// ADMIN LOGIN DETAILS
// ============================================================

const ADMIN_USERNAME = "admin";
const ADMIN_PASSWORD = "Admin@123";


// ============================================================
// MIDDLEWARE
// ============================================================

app.use(cors());

app.use(
    express.json({
        limit: "10mb"
    })
);


// ============================================================
// SESSION
// ============================================================

app.use(
    session({

        secret: "DBMS_Attendance_System_Secret_2026",

        resave: false,

        saveUninitialized: false,

        cookie: {

            httpOnly: true,

            secure: false,

            maxAge: 2 * 60 * 60 * 1000

        }

    })
);


// ============================================================
// DATABASE
// ============================================================

const db = new sqlite3.Database(
    "./attendance.db",
    (error) => {

        if (error) {

            console.error(
                "Database connection error:",
                error
            );

        } else {

            console.log(
                "Connected to SQLite database."
            );

        }

    }
);


// ============================================================
// CREATE TABLES
// ============================================================

db.serialize(() => {

    db.run(`

        CREATE TABLE IF NOT EXISTS students (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            name TEXT NOT NULL,

            section TEXT NOT NULL,

            roll_number TEXT NOT NULL UNIQUE,

            face_descriptor TEXT NOT NULL

        )

    `);


    db.run(`

        CREATE TABLE IF NOT EXISTS attendance (

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            student_id INTEGER NOT NULL,

            date TEXT NOT NULL,

            time TEXT NOT NULL,

            UNIQUE(student_id, date),

            FOREIGN KEY(student_id)
                REFERENCES students(id)

        )

    `);


    console.log(
        "Database tables are ready."
    );

});


// ============================================================
// ADMIN AUTHENTICATION
// ============================================================

function requireAdmin(req, res, next) {

    if (
        req.session &&
        req.session.isAdmin === true
    ) {

        next();

        return;

    }


    if (
        req.path.startsWith("/api/")
    ) {

        return res.status(401).json({

            success: false,

            message: "Admin login required."

        });

    }


    res.redirect(
        "/login.html"
    );

}


// ============================================================
// ADMIN LOGIN
// ============================================================

app.post(
    "/api/admin/login",
    (req, res) => {

        const {
            username,
            password
        } = req.body;


        if (
            username === ADMIN_USERNAME &&
            password === ADMIN_PASSWORD
        ) {

            req.session.isAdmin = true;


            return res.json({

                success: true,

                message: "Login successful."

            });

        }


        res.status(401).json({

            success: false,

            message: "Invalid username or password."

        });

    }
);


// ============================================================
// CHECK ADMIN LOGIN
// ============================================================

app.get(
    "/api/admin/check",
    (req, res) => {

        if (
            req.session &&
            req.session.isAdmin === true
        ) {

            return res.json({

                loggedIn: true

            });

        }


        res.json({

            loggedIn: false

        });

    }
);


// ============================================================
// ADMIN LOGOUT
// ============================================================

app.post(
    "/api/admin/logout",
    (req, res) => {

        req.session.destroy(
            (error) => {

                if (error) {

                    console.error(
                        "Logout error:",
                        error
                    );


                    return res.status(500).json({

                        success: false,

                        message: "Logout failed."

                    });

                }


                res.json({

                    success: true,

                    message: "Logged out successfully."

                });

            }
        );

    }
);


// ============================================================
// PROTECT ADMIN PAGE
// ============================================================

app.get(
    "/admin.html",
    requireAdmin,
    (req, res) => {

        res.sendFile(

            path.join(
                __dirname,
                "public",
                "admin.html"
            )

        );

    }
);


// ============================================================
// REGISTER STUDENT
// ============================================================

app.post(
    "/api/register",
    requireAdmin,
    (req, res) => {

        const {
            name,
            section,
            rollNumber,
            faceDescriptor
        } = req.body;


        if (!name ||
            !section ||
            !rollNumber ||
            !faceDescriptor
        ) {

            return res.status(400).json({

                success: false,

                message: "Please fill all fields and capture the face."

            });

        }


        const sql = `

            INSERT INTO students

            (
                name,
                section,
                roll_number,
                face_descriptor
            )

            VALUES (?, ?, ?, ?)

        `;


        db.run(

            sql,

            [

                name,

                section,

                rollNumber,

                JSON.stringify(
                    faceDescriptor
                )

            ],

            function(error) {

                if (error) {

                    console.error(
                        "Registration error:",
                        error
                    );


                    if (
                        error.message.includes(
                            "UNIQUE"
                        )
                    ) {

                        return res.status(400).json({

                            success: false,

                            message: "This roll number is already registered."

                        });

                    }


                    return res.status(500).json({

                        success: false,

                        message: "Could not register student."

                    });

                }


                res.json({

                    success: true,

                    message: "Student registered successfully!",

                    studentId: this.lastID

                });

            }

        );

    }
);


// ============================================================
// GET ALL STUDENTS
// ============================================================

app.get(
    "/api/students",
    (req, res) => {

        db.all(

            `

            SELECT

                id,

                name,

                section,

                roll_number,

                face_descriptor

            FROM students

            ORDER BY name ASC

            `,

            [],

            (error, rows) => {

                if (error) {

                    console.error(
                        "Student database error:",
                        error
                    );


                    return res.status(500).json({

                        success: false,

                        message: "Database error."

                    });

                }


                const students =
                    rows.map(
                        (student) => {

                            return {

                                id: student.id,

                                name: student.name,

                                section: student.section,

                                roll_number: student.roll_number,

                                face_descriptor: JSON.parse(
                                    student.face_descriptor
                                )

                            };

                        }
                    );


                res.json(
                    students
                );

            }

        );

    }
);


// ============================================================
// MARK ATTENDANCE
// ============================================================

app.post(
    "/api/attendance",
    (req, res) => {

        const {
            studentId
        } = req.body;


        if (!studentId) {

            return res.status(400).json({

                success: false,

                message: "Student ID is required."

            });

        }


        const now =
            new Date();


        const date =
            now
            .toISOString()
            .split("T")[0];


        const time =
            now.toLocaleTimeString(
                "en-IN"
            );


        const sql = `

            INSERT INTO attendance

            (
                student_id,
                date,
                time
            )

            VALUES (?, ?, ?)

        `;


        db.run(

            sql,

            [

                studentId,

                date,

                time

            ],

            function(error) {

                if (error) {

                    if (
                        error.message.includes(
                            "UNIQUE"
                        )
                    ) {

                        return res.json({

                            success: false,

                            message: "Attendance already marked today."

                        });

                    }


                    console.error(
                        "Attendance error:",
                        error
                    );


                    return res.status(500).json({

                        success: false,

                        message: "Could not mark attendance."

                    });

                }


                res.json({

                    success: true,

                    message: "Attendance marked successfully!",

                    date: date,

                    time: time

                });

            }

        );

    }
);


// ============================================================
// DASHBOARD
// ============================================================
//
// Returns:
// 1. Total students
// 2. Present students today
// 3. Absent students today
// 4. Names of students present today
//
// ============================================================

app.get(
    "/api/dashboard",
    requireAdmin,
    (req, res) => {

        const today =
            new Date()
            .toISOString()
            .split("T")[0];


        // ----------------------------------------------------
        // TOTAL STUDENTS
        // ----------------------------------------------------

        db.get(

            `

            SELECT COUNT(*) AS totalStudents

            FROM students

            `,

            [],

            (studentError, studentResult) => {

                if (studentError) {

                    console.error(
                        "Student count error:",
                        studentError
                    );


                    return res.status(500).json({

                        success: false,

                        message: "Could not get total students."

                    });

                }


                // ------------------------------------------------
                // PRESENT STUDENTS
                // ------------------------------------------------

                db.all(

                    `

                    SELECT

                        students.id,

                        students.name,

                        students.section,

                        students.roll_number,

                        attendance.date,

                        attendance.time

                    FROM attendance

                    INNER JOIN students

                    ON attendance.student_id =
                       students.id

                    WHERE attendance.date = ?

                    ORDER BY attendance.time ASC

                    `,

                    [today],

                    (attendanceError, presentStudents) => {

                        if (attendanceError) {

                            console.error(
                                "Attendance error:",
                                attendanceError
                            );


                            return res.status(500).json({

                                success: false,

                                message: "Could not get attendance."

                            });

                        }


                        const presentToday =
                            presentStudents.length;


                        const absentToday =
                            Math.max(
                                0,
                                studentResult.totalStudents -
                                presentToday
                            );


                        // ------------------------------------------------
                        // SEND EVERYTHING TO ADMIN DASHBOARD
                        // ------------------------------------------------

                        res.json({

                            success: true,

                            date: today,

                            totalStudents: studentResult.totalStudents,

                            presentToday: presentToday,

                            absentToday: absentToday,

                            presentStudents: presentStudents

                        });

                    }

                );

            }

        );

    }
);


// ============================================================
// GET ALL ATTENDANCE RECORDS
// ============================================================

app.get(
    "/api/attendance",
    requireAdmin,
    (req, res) => {

        const sql = `

            SELECT

                attendance.id,

                students.name,

                students.section,

                students.roll_number,

                attendance.date,

                attendance.time

            FROM attendance

            INNER JOIN students

            ON attendance.student_id =
               students.id

            ORDER BY

                attendance.date DESC,

                attendance.time DESC

        `;


        db.all(

            sql,

            [],

            (error, rows) => {

                if (error) {

                    console.error(
                        "Attendance database error:",
                        error
                    );


                    return res.status(500).json({

                        success: false,

                        message: "Database error."

                    });

                }


                res.json(
                    rows
                );

            }

        );

    }
);


// ============================================================
// SERVE WEBSITE FILES
// ============================================================

app.use(

    express.static(

        path.join(
            __dirname,
            "public"
        )

    )

);


// ============================================================
// START SERVER
// ============================================================

app.listen(

    PORT,

    () => {

        console.log("");

        console.log(
            "================================="
        );

        console.log(
            " Student Attendance System"
        );

        console.log(
            "================================="
        );

        console.log(
            `Server running at http://localhost:${PORT}`
        );

        console.log("");

        console.log(
            "Admin username: admin"
        );

        console.log(
            "Admin password: Admin@123"
        );

        console.log("");

    }

);